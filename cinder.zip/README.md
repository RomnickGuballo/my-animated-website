# Cinder

Your site, exported from [ScrollCraft](https://scrollcraft.space).
Plain HTML, CSS and JavaScript: no build step, no framework, no ScrollCraft account
needed. It is yours outright.

## Put it online

Pick whichever is easiest. All of them are free for a site this size.

**Netlify (free account)**
1. Create a free account at https://app.netlify.com/signup
2. While signed in, open https://app.netlify.com/drop
3. Drag the unzipped folder onto the page.
Without an account, Netlify keeps the site private and deletes it unless you claim it.
`netlify.toml` is already here and sets long cache headers on the frames.

**Vercel**
```sh
npx vercel deploy --prod
```
Run it inside this folder. `vercel.json` is already configured.

**GitHub Pages**
1. Create a repository and push this folder to it.
2. Settings → Pages → Source: deploy from branch, root.
The `.nojekyll` file is included, without which GitHub silently drops files whose names
begin with an underscore.

**Cloudflare Pages**
Create a project, connect the repository, and leave the build command empty with the
output directory set to `/`.

**Any other host**
Upload the contents of this folder to the web root. There is nothing to compile.

## Look at it locally first

Open a terminal in this folder and run:
```sh
npx serve .
```
Then open the address it prints.

Extract the whole ZIP before opening anything. Opening `index.html` from inside the ZIP
copies only that one file somewhere temporary, so the page loads without its `frames`
folder and the background stays black. The page tells you when that has happened.

## What is in here

| File | What it is |
| --- | --- |
| `index.html` | Your whole site |
| `404.html` | Shown for an address that does not exist |
| `favicon.svg` | The icon in the browser tab |
| `og-image.jpg` | The preview image when the link is shared |
| `apple-touch-icon.png` | The icon when saved to a phone's home screen |
| `robots.txt` | Tells search engines they may index the site |


The background is drawn in the browser from a small style recipe, so there is no
`frames/` folder. The page itself is about 30 KB; the social preview image is the only
file larger than that.

## Making changes

Everything is editable in a text editor.

- **Words** — search `index.html` for the text you want to change.
- **Colours** — near the top of the `<style>` block, the `--sc-` custom properties.
- **Social preview** — replace `og-image.jpg` with your own 1200×630 image.
- **Icon** — replace `favicon.svg`.

### The one thing only you can do

Your call-to-action button needs a real destination. Templates ship it pointing at a
placeholder, because only you know whether it should open a signup page, a booking form
or your inbox. Search `index.html` for the button's text and set its `href`:

```html
<a href="https://your-domain.com/signup" ...>Get started</a>
```

`mailto:you@your-domain.com` and `tel:+1234567890` both work too. A button whose
`href` starts with `#` scrolls to a section of this page; `#section-1` is the first
section, `#section-2` the second, and so on.

### One thing worth doing

The social preview and canonical address are relative, which works on most platforms but
not all. Once you know your real address, search `index.html` for `og-image.jpg` and make
it absolute:

```html
<meta property="og:image" content="https://your-domain.com/og-image.jpg" />
```

## Accessibility

The exported page already ships with a skip link, visible keyboard focus, an accessible
name on the background canvas, a `prefers-reduced-motion` fallback that disables the
reveal animations, and a `<noscript>` fallback that shows all content when JavaScript is
unavailable. If you edit the markup, keep the heading order intact — one `<h1>`, then
`<h2>`s — and give any image you add real `alt` text.
